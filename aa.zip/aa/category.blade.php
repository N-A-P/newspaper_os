@extends('client.layouts.index')
@section('content')
    <div class="row">
        <div class="col-12 col-lg-8">
                <div class="blog-posts-area">

                    <!-- Single Featured Post -->
                    <div class="single-blog-post featured-post mb-30">
                        <div class="post-thumb">
                            <a href="#"><img src="img/bg-img/25.jpg" alt=""></a>
                        </div>
                        <div class="post-data">
                            <a href="#" class="post-catagory">Finance</a>
                            <a href="#" class="post-title">
                                <h6>Financial news: A new company is born today at the stock market</h6>
                            </a>
                            <div class="post-meta">
                                <p class="post-author">By <a href="#">Christinne Williams</a></p>
                                <p class="post-excerp">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam eu metus sit amet odio sodales placerat. Sed varius leo ac leo fermentum, eu cursus nunc maximus. Integer convallis nisi nibh, et ornare neque ullamcorper ac. Nam id congue lectus, a venenatis massa. Maecenas justo libero, vulputate vel nunc id, blandit feugiat sem. </p>
                                <!-- Post Like & Post Comment -->
                                <div class="d-flex align-items-center">
                                    <a href="#" class="post-like"><img src="img/core-img/like.png" alt=""> <span>392</span></a>
                                    <a href="#" class="post-comment"><img src="img/core-img/chat.png" alt=""> <span>10</span></a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Single Featured Post -->
                    <div class="single-blog-post featured-post mb-30">
                        <div class="post-thumb">
                            <a href="#"><img src="img/bg-img/26.jpg" alt=""></a>
                        </div>
                        <div class="post-data">
                            <a href="#" class="post-catagory">Finance</a>
                            <a href="#" class="post-title">
                                <h6>Pompeo moves to reassure skeptical Dems in bid to be US diplomat</h6>
                            </a>
                            <div class="post-meta">
                                <p class="post-author">By <a href="#">Christinne Williams</a></p>
                                <p class="post-excerp">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam eu metus sit amet odio sodales placerat. Sed varius leo ac leo fermentum, eu cursus nunc maximus. Integer convallis nisi nibh, et ornare neque ullamcorper ac. Nam id congue lectus, a venenatis massa. Maecenas justo libero, vulputate vel nunc id, blandit feugiat sem. </p>
                                <!-- Post Like & Post Comment -->
                                <div class="d-flex align-items-center">
                                    <a href="#" class="post-like"><img src="img/core-img/like.png" alt=""> <span>392</span></a>
                                    <a href="#" class="post-comment"><img src="img/core-img/chat.png" alt=""> <span>10</span></a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Single Featured Post -->
                    <div class="single-blog-post featured-post mb-30">
                        <div class="post-thumb">
                            <a href="#"><img src="img/bg-img/27.jpg" alt=""></a>
                        </div>
                        <div class="post-data">
                            <a href="#" class="post-catagory">Finance</a>
                            <a href="#" class="post-title">
                                <h6>Most investors think 2018 is the peak year for stocks</h6>
                            </a>
                            <div class="post-meta">
                                <p class="post-author">By <a href="#">Christinne Williams</a></p>
                                <p class="post-excerp">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam eu metus sit amet odio sodales placerat. Sed varius leo ac leo fermentum, eu cursus nunc maximus. Integer convallis nisi nibh, et ornare neque ullamcorper ac. Nam id congue lectus, a venenatis massa. Maecenas justo libero, vulputate vel nunc id, blandit feugiat sem. </p>
                                <!-- Post Like & Post Comment -->
                                <div class="d-flex align-items-center">
                                    <a href="#" class="post-like"><img src="img/core-img/like.png" alt=""> <span>392</span></a>
                                    <a href="#" class="post-comment"><img src="img/core-img/chat.png" alt=""> <span>10</span></a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Single Featured Post auto luôn -->
                    <div class="single-blog-post featured-post mb-30">
                        <div class="post-thumb">
                            <a href="#"><img src="img/bg-img/28.jpg" alt=""></a>
                        </div>
                        <div class="post-data">
                            <a href="#" class="post-catagory">Finance</a>
                            <a href="#" class="post-title">
                                <h6>Facebook is offering facial recognition again in Europe</h6>
                            </a>
                            <div class="post-meta">
                                <p class="post-author">By <a href="#">Christinne Williams</a></p>
                                <p class="post-excerp">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam eu metus sit amet odio sodales placerat. Sed varius leo ac leo fermentum, eu cursus nunc maximus. Integer convallis nisi nibh, et ornare neque ullamcorper ac. Nam id congue lectus, a venenatis massa. Maecenas justo libero, vulputate vel nunc id, blandit feugiat sem. </p>
                                <!-- Post Like & Post Comment -->
                                <div class="d-flex align-items-center">
                                    <a href="#" class="post-like"><img src="img/core-img/like.png" alt=""> <span>392</span></a>
                                    <a href="#" class="post-comment"><img src="img/core-img/chat.png" alt=""> <span>10</span></a>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <nav aria-label="Page navigation example">
                    <ul class="pagination mt-50">
                        <li class="page-item active"><a class="page-link" href="#">1</a></li>
                        <li class="page-item"><a class="page-link" href="#">2</a></li>
                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                        <li class="page-item"><a class="page-link" href="#">4</a></li>
                        <li class="page-item"><a class="page-link" href="#">5</a></li>
                        <li class="page-item"><a class="page-link" href="#">...</a></li>
                        <li class="page-item"><a class="page-link" href="#">10</a></li>
                    </ul>
                </nav>
            </div>
    </div>
@endsection